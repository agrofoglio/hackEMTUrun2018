<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>BLA BLA BUS</title>
	</head>
	<body>
		<?php
			session_start();
			$_SESSION[sid]=htmlspecialchars("0"); //Registra log indicando o servico 0, referente ao usuario na pagina inicial do sistema
			require_once('hackEMTU2018localiza.php');
		?>
		<p>Bem vindo ao Blá Blá Bus</p>
		<p><a href="hackEMTU2018blabla.php" target="_parent">Blá Blá Bus Chat</a></p>
		<p><a href="hackEMTU2018denuncia.php" target="_parent">Denúncia</a></p>
		<p><a href="hackEMTU2018panico.php" target="_parent">Pânico</a></p>
		<p><a href="hackEMTU2018qualidade.php" target="_parent">Controle de qualidade</a></p>
		<p><a href="hackEMTU2018configuracoes.php" target="_parent">Configurações</a></p>
		<p><a href="hackEMTU2018recarga.php" target="_parent">Recarga</a></p>
	</body>
</html>