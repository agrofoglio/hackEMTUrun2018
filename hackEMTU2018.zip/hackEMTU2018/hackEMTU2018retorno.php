<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>RETORNO</title>
	</head>
	<body>
		<?php
			session_start();
			$_SESSION[sid]=htmlspecialchars("3"); //Registra log indicando o servico 3, retorno positivo de recebimento de denuncia
			require_once('hackEMTU2018localiza.php');
		?>
		<p>Obrigado pela sua denúncia. Nossa equipe já está averiguando o ocorrido.</p>
		<p><a href="hackEMTU2018index.php" target="_parent">Voltar ao início</a></p>
	</body>
</html>