<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>CHAT</title>
	</head>
	<body>
		<?php
			session_start();
			$_SESSION[sid]=htmlspecialchars("1"); //Registra log indicando o servico 1, entrada no chat do BlaBlaBus
			require_once('hackEMTU2018localiza.php');
		?>
		<p>Procurando por passageiros perto de você. Por favor, aguarde...</p>
		<p>Janela de tempo menor ou igual que 1 minuto, varrer:</p>
		<p>Distância -0,0020 na Latitude</p>
		<p>Distância +0,0020 na Latitude</p>
		<p>Distância -0,0060 na Longitude</p>
		<p>Distância +0,0060 na Longitude</p>
		<p><a href="hackEMTU2018index.php" target="_parent">Voltar ao início</a></p>
	</body>
</html>