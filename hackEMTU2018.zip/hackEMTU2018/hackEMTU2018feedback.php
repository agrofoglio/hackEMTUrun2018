<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>OBRIGADO</title>
	</head>
	<body>
		<?php
			session_start();
			$_SESSION[sid]=htmlspecialchars("7"); //Registra log indicando o servico 7, feedback da pesquisa de qualidade (motorista e carro)
			require_once('hackEMTU2018localiza.php');
		?>
		<p>Obrigado pela sua avaliação. Você ajudou a melhorar o serviço para todos os usuários.</p>
		<p><a href="hackEMTU2018index.php" target="_parent">Voltar ao início</a></p>
	</body>
</html>