<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>DENUNCIE</title>
	</head>
	<body>
		<?php
			session_start();
			$_SESSION[sid]=htmlspecialchars("2"); //Registra log indicando o servico 2, acesso a pagina de denuncia
			require_once('hackEMTU2018localiza.php');
		?>
		<p>Descreva a sua denúncia (se possível, envie uma foto)</p>
		<form method="POST" action="/hackEMTU2018retorno.php">
			<textarea name="denuncia" rows="5" cols="80"></textarea><br />
			<input type="file" name="foto" /><br /><br />
			<input type="submit" name="submitted" value="Denunciar">
		</form>
		<p><a href="hackEMTU2018index.php" target="_parent">Voltar ao início</a></p>
	</body>
</html>