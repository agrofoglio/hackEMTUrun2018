<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>PANICO</title>
	</head>
	<body>
		<?php
			session_start();
			$_SESSION[sid]=htmlspecialchars("4");
			require_once('hackEMTU2018localiza.php');
		?>
		<p>Aguarde, já localizamos sua posição e estamos enviando a ajuda!</p>
		<form method="POST" action="/hackEMTU2018ajuda.php">
			<input type="submit" name="submitted" value="Solicitar Ajuda">
		</form>
		<p><a href="hackEMTU2018index.php" target="_parent">Voltar ao início</a></p>
	</body>
</html>