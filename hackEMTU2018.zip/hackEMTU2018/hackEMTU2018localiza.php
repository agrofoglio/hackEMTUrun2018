<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
    	<script src="js/jquery-3.3.1.min.js"></script>
	</head>
	<body>
		<p id="aba"></p>
		<script>
			$( document ).ready(function() {
  				navigator.geolocation.getCurrentPosition(showPosition);}); //ativa o sensor de localizacao do aparelho
			function showPosition(position) {
    			console.log(position);
				var latitude=position.coords.latitude; //recebe dados da latitude
				var longitude=position.coords.longitude; //recebe dados da longitude
				var acuraciacoordenadas=position.coords.accuracy; //recebe dados da acuracia sobre a latitude e a longitude
				var altitude=position.coords.altitude; //recebe dados da altitude
				var acuraciaaltitude=position.coords.altitudeAccuracy; //recebe dados da acuracia da altitude
				var graus=position.coords.heading; //recebe dados da latitude
				var velocidade=position.coords.speed; //recebe dados da latitude
				var datahora=position.timestamp; //recebe dados da latitude
    			var dataPost = {latitude: latitude, longitude: longitude, acuraciacoordenadas: acuraciacoordenadas, altitude: altitude, acuraciaaltitude: acuraciaaltitude, graus: graus, velocidade: velocidade, datahora: datahora }; //recebe dados da latitude
    			$.post( "hackEMTU2018leitura.php?acao=retornaPosicao", dataPost, function( retorno ) {
			        console.log( retorno );}); //recebe dados da latitude
    		}
		</script>
	</body>
</html>