<?php
	$conexao=mysql_connect() or die("Erro 1. Por favor, contate a equipe Run, mesa 15, HackEMTU 2018");
	mysql_select_db() or die("Erro 2. Por favor, contate a equipe Run, mesa 15, HackEMTU 2018");
?>