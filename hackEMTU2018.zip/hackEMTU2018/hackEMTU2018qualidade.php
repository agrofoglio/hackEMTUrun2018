<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>QUALIDADE</title>
	</head>
	<body>
		<?php
			session_start();
			$_SESSION[sid]=htmlspecialchars("6"); //Registra log indicando o servico 5, ajuda referente ao botao do panico enviada
			require_once('hackEMTU2018localiza.php');
		?>
		<p>Aqui você pode avaliar a linha utilizada.</p>
		<form method="POST" action="/hackEMTU2018feedback.php">
			<p>Qual sua nota para o motorista?</p>
			<p><input type="radio" name="MOTORISTAnota" value="1" />Nota 1&nbsp;&nbsp;&nbsp;
				<input type="radio" name="MOTORISTAnota" value="2" />Nota 2&nbsp;&nbsp;&nbsp;
				<input type="radio" name="MOTORISTAnota" value="3" />Nota 3&nbsp;&nbsp;&nbsp;
				<input type="radio" name="MOTORISTAnota" value="4" />Nota 4&nbsp;&nbsp;&nbsp;
				<input type="radio" name="MOTORISTAnota" value="5" />Nota 5</p>
			<p>Qual sua nota para o veículo (ônibus)?</p>
			<p><input type="radio" name="CARROnota" value="1" />Nota 1&nbsp;&nbsp;&nbsp;
				<input type="radio" name="CARROnota" value="2" />Nota 2&nbsp;&nbsp;&nbsp;
				<input type="radio" name="CARROnota" value="3" />Nota 3&nbsp;&nbsp;&nbsp;
				<input type="radio" name="CARROnota" value="4" />Nota 4&nbsp;&nbsp;&nbsp;
				<input type="radio" name="CARROnota" value="5" />Nota 5</p>
			<input type="submit" name="submitted" value="Avaliar">
		</form>
		<p><a href="hackEMTU2018index.php" target="_parent">Voltar ao início</a></p>
	</body>
</html>