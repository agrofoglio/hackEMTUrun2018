<?php
    session_start();
    $acao=$_GET["acao"];
    if($acao=="retornaPosicao"){
        retornaPosicao();}
    function retornaPosicao(){
        $latitude=htmlspecialchars($_POST["latitude"]);
        $longitude=htmlspecialchars($_POST["longitude"]);
        $acuraciacoordenadas=htmlspecialchars($_POST["acuraciacoordenadas"]);
        $altitude=htmlspecialchars($_POST["altitude"]);
        $acuraciaaltitude=htmlspecialchars($_POST["acuraciaaltitude"]);
        $graus=htmlspecialchars($_POST["graus"]);
        $velocidade=htmlspecialchars($_POST["velocidade"]);
        $datahora=htmlspecialchars($_POST["datahora"]);
        //$uid=htmlspecialchars(session_id());
        $uid=htmlspecialchars("123456");
        require ('hackEMTU2018conecta.php');
        $sqx="INSERT INTO hackEMTU2018log VALUES (NULL,'".$uid."','".$_SESSION[sid]."','".$latitude."','".$longitude."','".$acuraciacoordenadas."','".$altitude."','".$acuraciaaltitude."','".$graus."','". $velocidade."','".$datahora."',NULL)";
        $qux=mysql_query($sqx);
        $_SESSION[cly]=mysql_insert_id($conexao);
        mysql_close($conexao);}
?>