<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>RECARGA</title>
	</head>
	<body>
		<?php
			session_start();
			$_SESSION[sid]=htmlspecialchars("9"); //Registra log indicando o servico 9, acesso ao sistema de recarga do cartao de transporte
			require_once('hackEMTU2018localiza.php');
		?>
		<p>Você recarregou o seu cartão com sucesso, por favor, procure um ponto de validação.</p>
		<p><a href="hackEMTU2018index.php" target="_parent">Voltar ao início</a></p>
	</body>
</html>