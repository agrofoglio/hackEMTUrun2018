<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>PERFIL</title>
	</head>
	<body>
		<?php
			session_start();
			$_SESSION[sid]=htmlspecialchars("8"); //Registra log indicando o servico 8, entrada nas configuracoes de perfil
			require_once('hackEMTU2018localiza.php');
		?>
		<p>Configurações de perfil</p>
		<p><a href="hackEMTU2018index.php" target="_parent">Voltar ao início</a></p>
	</body>
</html>