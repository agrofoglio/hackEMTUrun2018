<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>AJUDA ENVIADA</title>
	</head>
	<body>
		<?php
			session_start();
			$_SESSION[sid]=htmlspecialchars("5"); //Registra log indicando o servico 5, ajuda referente ao botao do panico enviada
			require_once('hackEMTU2018localiza.php');
		?>
		<p>Já enviamos ajuda. Por favor, aguarde!</p>
		<p><a href="hackEMTU2018index.php" target="_parent">Voltar ao início</a></p>
	</body>
</html>